<template>
  <div class="row contenedor">

  </div>
</template>

<script>
export default {
  name: 'Quienes',
  components: {

  }
}
</script>

<style scoped>
.contenedor{
  height: 100%;
}
</style>
