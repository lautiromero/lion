<template>
  <div class="row">
    <div class="col-md-8 section px-5">
      <MenuBot/>
    </div>
    <div class="col-md-4 px-5">
      <Contact/>
    </div>
  </div>
</template>

<script>
import MenuBot from '../Menu-bot';
import Contact from '../Contact';
export default {
  name: 'Home',
  components: {
    Contact,
    MenuBot
  }
}
</script>

<style scoped>
.section{
  background: url("../../assets/images/back-home.png") no-repeat;
  background-position: center center;
  background-size: contain;
}

</style>
