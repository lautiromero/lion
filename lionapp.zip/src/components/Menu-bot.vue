<template>
  <div class="d-flex justify-content-around align-items-center" id="cont-menu-bot">
    <div class="bot-item overflow-hidden">
      <div class="white-box bg-white d-inline">
        <i class="fa fa-map-marked-alt"></i>
      </div>
      <a href="#">SUCURSALES</a>
    </div>
    <div class="bot-item overflow-hidden">
      <div class="white-box bg-white d-inline">
        <i class="fa fa-car"></i>
      </div>
      <a href="#">ENTREGAS</a>
    </div>
    <div class="bot-item overflow-hidden">
      <div class="white-box bg-white d-inline">
        <i class="fa fa-comments"></i>
      </div>
      <a href="#">NOVEDADES</a>
    </div>
    <div class="bot-item overflow-hidden">
      <div class="white-box bg-white d-inline">
        <i class="fa fa-bullhorn"></i>
      </div>
      <a href="#">PROMOCIONES</a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MenuBot',
  components: {

  }
}
</script>

<style scoped>
#cont-menu-bot{
  height: 100%;
}
.bot-item{
  background-color: #6DA1BE;
  border: 1px solid rgba(246, 246, 246, 0.56);
  padding-top: .15rem ;
  padding-bottom: .15rem ;
  padding-right: .25rem ;
  border-bottom-left-radius: 6pt;
  border-top-right-radius: 6pt;
  font-size: 13px;

}
.white-box{
  border-bottom-left-radius: 7pt;
  border-top-right-radius: 7pt;
  /* font-size: 11px; */
  padding: .40rem;
  font-size: 14px;
}
svg{
  color:#7FA4BF!important;
}
</style>
