<template>
  <div id="container-footer" class="d-flex px-5 justify-content-between">
      <ul class="list-unstyled d-flex align-items-center justify-content-around ul-footer">
        <li class="li-footer">
          <a href="tel:+54903514262718"><i class="fa fa-phone"></i> +549 0351-4262718</a>
        </li>
        <li class="li-footer">
          <a href="mailto:info@financegroup.com.ar"><i class="fas fa-envelope"></i> INFO@FINANCEGROUP.COM.AR</a>
        </li>
        <li class="li-footer">
          <span class="text-white small">Las imágenes publicadas en este<br> sitio son de carácter ilustrativo.</span>
        </li>
      </ul>
      <ul class="list-unstyled m-0 d-flex ul-social align-items-end overflow-hidden pb-2">
        <li class="li-social">
          <a class="p-2" href="#"><i class="fab fa-facebook-square"></i></a>
        </li>
        <li class="li-social">
          <a class="p-2" href="#"><i class="fab fa-twitter-square"></i></a>
        </li>
        <li class="li-social">
          <a class="p-2" href="#"><i class="fab fa-instagram"></i></a>
        </li>
      </ul>
  </div>
</template>

<script>
export default {
  name: 'Footer',
  components: {

  }
}
</script>

<style scoped>
#container-footer{
  position: absolute;
  width: 100%;
  bottom:0;
  height: 58px;
  background: url("../assets/images/footer-01.png") no-repeat;
  background-position: right top;
  background-size: cover;
}
.ul-footer{
  height: 100%;
}
.ul-social{

}
.li-footer{
  padding-left: 30px;
  padding-right: 30px;
}
</style>
