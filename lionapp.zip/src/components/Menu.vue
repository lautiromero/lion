<template>
    <div id="menu-container" class="px-4">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-2 text-center dfa">
            <a class="navbar-brand" href="#">
            <img src="../assets/logo-test.png" width="170" alt="">
          </a>
          </div>
          <div class="col-md-5">
            <ul class="list-unstyled d-flex align-items-center" style="height:100%">
              <li class="">
                <router-link to="/">HOME</router-link>
              </li>
              <li class="">
                <router-link to="/quienes-somos">QUIENES SOMOS</router-link>
              </li>
              <li class="">
                <a class="" href="#">CONTACTO</a>
              </li>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="list-unstyled dfa" style="height:100%">
              <li class="">
                <a class="p-2" href="#"><i class="fab fa-facebook-square"></i></a>
              </li>
              <li class="">
                <a class="p-2" href="#"><i class="fab fa-twitter-square"></i></a>
              </li>
              <li class="">
                <a class="p-2" href="#"><i class="fab fa-instagram"></i></a>
              </li>
            </ul>
          </div>
        </div>

      </div>

    </div>
</template>

<script>
export default {
  name: 'Menu',
  components: {

  }
}
</script>

<style scoped>
#menu-container{
  background: url("../assets/images/Header-back2.png") no-repeat;
  background-position: right bottom;
  background-size: cover;
  max-height: 85.55px;
  /* max-height: 85.55px; */
}
/* .nav-link{
  padding-right: 1rem !important;
  padding-left: 1rem !important;
} */
li a {
  color: white;
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  max-height: 85.55px;
  text-decoration: none;
  padding-left: 1.9em;
  padding-right: 1.9em;
}
li a:hover{
  background-color:#B3CADC;
}
li {
  display: inline;
  height: 100%;
  max-height: 85.55px;
  align-items: center;
}
</style>


<!-- <div >
<div class="d-flex justify-content-between pl-3" style="width:80%">
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#">HOME</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">QUIENES SOMOS</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">CONTACTO</a>
    </li>
  </ul>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#"><i class="fab fa-facebook-square"></i></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><i class="fab fa-twitter-square"></i></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><i class="fab fa-instagram"></i></a>
    </li>
  </ul>
</div>

</div>
     -->
